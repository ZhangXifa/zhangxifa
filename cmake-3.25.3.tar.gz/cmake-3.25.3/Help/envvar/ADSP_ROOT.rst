ADSP_ROOT
---------

.. versionadded:: 3.24

.. include:: ENV_VAR.txt

The ``ADSP_ROOT`` environment variable specifies a default value
for the :variable:`CMAKE_ADSP_ROOT` variable when there is no explicit
configuration given on the first run while creating a new build tree.
